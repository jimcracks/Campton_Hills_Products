/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.net.URLEncoder;

def Message processData(Message message) {
    
  Reader reader = message.getBody(Reader)
  def input = new JsonSlurper().parse(reader)
  def properties = input.d.results

  String cr = "%0A";
  String sp = "%20";
  String tb = "%09";
 
  String line1 = "South Side Supply, Inc.";
  String line2 = "ID:"+tb+properties.ProductID[0];
  String line3 = "Desc:"+tb+properties.Description[0];
  String line4 = "UOM:"+tb+properties.BaseUOM[0]+sp+'-'+sp+properties.BaseUOMText[0];
  //String line5 = "https%3A%2F%2Fcamptonhills.com%2Forder_now%3FProductID%3D%27"+properties.ProductID[0]+"%27";
 
  String qr_string = line1+cr+line2+cr+line3+cr+line4;

  message.setProperty("qr_string", qr_string);
  message.setProperty("props", properties);
 
  return message

}