/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
 import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.mapping.MappingContext
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
 

def Message processData(Message message) {
    //Body 
def body = message.getBody(String.class);	

     def messageLog = messageLogFactory.getMessageLog(message);
     
       //Headers 
      def map = message.getHeaders();
       def value = map.get("materialID");
     //  message.setHeader("oldHeader", value + "modified");
     //  message.setHeader("newHeader", "newHeader");
       
       //Properties 
       //map = message.getProperties();
       //value = map.get("oldProperty");
       
    // def queryParams = message.getHeader('CamelHttpQuery')?.split('&');
       
	//def queryParamsMap = queryParams.collectEntries { param ->
	//	param.split('=').collect {
	//		URLDecoder.decode(it, StandardCharsets.UTF_8.name())
	//	}
	//}
	       message.setBody(value);
       
	if(messageLog != null)
    {
	messageLog.addAttachmentAsString("Log current Payload:", body, "text/plain");
	}

	
       message.setProperty("materialID", value);
       message.setBody(value);
       return message;
}

