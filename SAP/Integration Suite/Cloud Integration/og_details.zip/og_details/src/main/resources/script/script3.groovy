/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
 
    def body = message.getBody();
    def map = message.getProperties();
    def props = map.get("props");
    def s3_url = map.get("s3_url");
    
    String encoded = body.bytes.encodeBase64().toString();

    def json = JsonOutput.toJson([
        ProductID: props.ProductID[0], 
        Description: props.Description[0],
        BaseUOM: props.BaseUOM[0],
        BaseUOMText: props.BaseUOMText[0],
        UUID: props.UUID[0],
        ImageURL: s3_url + props.ProductID[0] + '.png',
        ProductCategoryID: props.ProductCategoryID[0],
        MinimumOrderQuantity: props.MinimumOrderQuantity[0],
        label: encoded
        ]);
           
    message.setHeader('Content-Type', 'application/json');
    message.setBody(json);
      
    return message;
}



