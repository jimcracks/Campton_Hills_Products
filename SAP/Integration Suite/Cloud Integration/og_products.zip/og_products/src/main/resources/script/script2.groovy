/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def body = message.getBody(java.lang.String)
    def slurper = new JsonSlurper().parseText(body)
    def mapProp = message.getProperties();
    def filter = mapProp.get("filter_string");
    def filter_set = false;
    
    if (filter)
      filter_set = true;

    if (slurper.Labels && !slurper.Labels.isEmpty()) {

        slurper.Labels.eachWithIndex {it,index->
        
            if (filter) {
                
               if (index == 0) {
                    filter += ' and ( ';
                } else {
                    filter += ' or ';
                }
       
            } else {
                filter = '';
            }   
       
            filter += "substringof('" + it.Name + "', Description)";        
        }
    
        if (filter_set)
          filter += " ) ";
    
    }
    
        message.setProperty("filter_string", filter);
     //   message.setBody(filter);
        
        return message;
}