/*
* The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util
 which includes helper methods useful for the content developer:
 The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
   public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
 */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function isBlank(str) {
    return (!str || /^\s*$/.test(str));
}

function processData(message) {
    //Get body
    var body = String(message.getBody( new java.lang.String().getClass()));
        message.setProperty("route", '2');
        return;
    //create json from string object
    body = JSON.parse(body);
    if (body.image.bytes)  {
        message.setProperty("route", '2');  //route 2 = image recognition
        return;
    }

    //Get Headers  
    var map = message.getHeaders();
    var product_id = map.get("product_id");
    var product_desc =  map.get("product_desc");
       
    //Determine Query Filter String
    var filter = '';
       
    if (!isBlank(product_id))
       filter = "ProductID eq '" + product_id + "'";
    
       
    if (!isBlank(product_desc)) {
        if (filter) {
           filter += ' & ';
        }
        filter += "substringof('" + product_desc + "', Description)";
    }
    
	//Set Properties 
    message.setProperty("filter_string", filter);
        
     return message;
             
    //map = message.getProperties();
    //value map.get("oldProperty");
    //  message.setHeader("oldHeader", value + "modified");
    //  message.setHeader("newHeader", "newHeader");
    //message.setBody(route);

}