/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders() 
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {

    //Get Headers  
    def map = message.getHeaders();
    def product_id = map.get("product_id");
    def product_desc =  map.get("product_desc");
    def filter = '';
    def labels;
    def rek_labels = [:];

 
     map.remove('authorization');
     
    body = message.getBody(java.lang.String)
    if (body) {
      def json = new JsonSlurper().parseText(body);
      labels = json.get('Labels');
    }
    
    if ( product_id?.trim() || 
         product_desc?.trim() || 
        ( labels != null && !labels.isEmpty() ))
        filter = '&$filter=';

    //Add Product ID to Filter String
    if (product_id?.trim()) {
        filter += "ProductID eq '" + product_id + "'";
        
        if (labels != null && !labels.isEmpty()) {
            filter += ' and ( ';
        } else if (product_desc?.trim()) {
            filter += ' and '
        }
    }  
    
    //Add Product Description to Filter String       
    if (product_desc?.trim()) {
        filter += "substringof('" + product_desc + "', Description)";
  //      rek_labels = product_desc;
                        
        if (labels != null && !labels.isEmpty())
            filter += ' or ';        
    }
    
    //Add Image Recognition Labels to Filter String (Product Description)
    if (labels != null && !labels.isEmpty()) {
        labels.eachWithIndex {it,index->
            if (filter?.trim() && index > 0) 
                filter += ' or ';
        
            filter += "substringof('" + it.Name + "', Description)";        

            rek_labels.put(it.Name,it.Confidence);
        }
    
        if (product_id?.trim()) 
            filter += " )";  
            
        //Clear Image Recognition Authorization Headers

    }
    
    //Set filter_string property
    message.setProperty("filter_string", filter);
        
                    
    def builder = new JsonBuilder(rek_labels);
    message.setHeader("rek_labels", builder.toString());        
    
   // message.setBody(filter);
        
        return message;
}